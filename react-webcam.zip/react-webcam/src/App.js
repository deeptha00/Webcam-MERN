import React from "react";
import WebcamImage from "./WebcamImage";
import './index.css';

function App() {
  return (
    <div className="App">
      <WebcamImage />
    </div>
  );
}

export default App;