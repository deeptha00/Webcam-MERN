import React, { useCallback, useRef, useState } from "react";
import Webcam from "react-webcam";

function WebcamImage() {
  const [img, setImg] = useState(null);
  const webcamRef = useRef(null);

  const videoConstraints = {
    width: 420,
    height: 420,
    facingMode: "user",
  };

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    setImg(imageSrc);
  }, [webcamRef]);

  return (
    <div className="flex flex-col justify-center items-center min-h-screen bg-gray-800 mx-10">
      {img === null ? (
        <>
          <Webcam
            audio={false}
            mirrored={true}
            height={400}
            width={400}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
            className="rounded-lg"
          />
          <button
            onClick={capture}
            className="bg-crimson text-white mt-10 px-10 py-2 rounded-full cursor-pointer"
          >
            Capture photo
          </button>
        </>
      ) : (
        <>
          <img src={img} alt="screenshot" className="h-400 w-400 object-cover rounded-lg" />
          <button
            onClick={() => setImg(null)}
            className="bg-crimson text-white mt-10 px-10 py-2 rounded-full cursor-pointer"
          >
            Retake
          </button>
        </>
      )}
    </div>
  );
}

export default WebcamImage;
